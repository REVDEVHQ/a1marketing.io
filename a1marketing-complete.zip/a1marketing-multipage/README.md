# A1 Marketing Website

Official website for A1 Marketing - Always First.

## 🚀 Live Site
[a1marketing.io](https://a1marketing.io)

## 📁 Project Structure
```
├── index.html       # Homepage
├── services.html    # Services page
├── about.html       # About page
├── styles.css       # Shared styles
├── script.js        # Shared JavaScript
├── CNAME            # Custom domain config
└── README.md
```

## 🛠️ Deployment to GitHub Pages

### Step 1: Create GitHub Repository
1. Go to [github.com](https://github.com) and create a new repository
2. Name it `a1marketing` (or any name you prefer)
3. Keep it public for free GitHub Pages hosting

### Step 2: Upload Files
Upload all files from this folder to your repository.

### Step 3: Enable GitHub Pages
1. Go to your repository **Settings**
2. Click **Pages** in the left sidebar
3. Under "Source", select **Deploy from a branch**
4. Select **main** branch and **/ (root)** folder
5. Click **Save**

### Step 4: Configure Custom Domain (a1marketing.io)

#### In GoHighLevel DNS Settings:
Add these DNS records (click "+ Add Record" for each):

**A Records (for apex domain):**
| Type | Name | Content |
|------|------|---------|
| A | @ | 185.199.108.153 |
| A | @ | 185.199.109.153 |
| A | @ | 185.199.110.153 |
| A | @ | 185.199.111.153 |

**CNAME Record (for www):**
| Type | Name | Content |
|------|------|---------|
| CNAME | www | YOUR-USERNAME.github.io |

Replace `YOUR-USERNAME` with your actual GitHub username.

#### In GitHub:
1. Go to repository **Settings** → **Pages**
2. Under "Custom domain", enter: `a1marketing.io`
3. Click **Save**
4. Wait for DNS to propagate (can take up to 24-48 hours)
5. Once verified, check **Enforce HTTPS**

## ✅ Verification
After DNS propagates, run this in terminal to verify:
```bash
dig a1marketing.io +nostats +nocomments +nocmd
```

You should see the GitHub Pages IP addresses (185.199.x.x) in the response.

## 📧 Contact
- Email: Always1stmarketing@gmail.com
- Instagram: [@always1stmarketing](https://www.instagram.com/always1stmarketing/)

---
© 2025 A1 Marketing. Always First.
